@extends('layouts.app')

@section('content')
  <div class="alert alert-danger">
    Apologies, that page cant be found!! Error 404
  </div>
@endsection
