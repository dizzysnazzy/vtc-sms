<?php

namespace vtc;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    //
}
