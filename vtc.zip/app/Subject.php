<?php

namespace vtc;

use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    //
}
