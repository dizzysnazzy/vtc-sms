<?php

namespace vtc;

use Illuminate\Database\Eloquent\Model;

class CombinedSubject extends Model
{
    protected $fillable = [
        'combined_name'
    ];

    public function units()
    {
        return $this->hasMany('vtc\Unit');
    }
}
