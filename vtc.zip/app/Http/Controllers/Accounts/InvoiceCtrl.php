<?php

namespace vtc\Http\Controllers\Accounts;

use Illuminate\Http\Request;
use vtc\Http\Controllers\Controller;

class InvoiceCtrl extends Controller
{
    //
}
